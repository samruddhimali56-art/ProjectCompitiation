import React from "react";

function Home() {
    return (
        <>
        <section
    style={{
        position: "relative",
        width: "100%",
        height: "80vh",
        backgroundImage:
            "url('https://i.ibb.co/pBVS8R2N/elegant-background-graphic-for-a-history-platform-a-subtle-abstract-map-with.png')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundRepeat: "no-repeat",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        textAlign: "center",
        overflow: "hidden",
    }}
>
    {/* Brown Overlay */}
    <div
        style={{
            position: "absolute",
            inset: 0,
            background: "linear-gradient(rgba(140,60,17,0.60), rgba(90,45,15,0.70))",
        }}
    ></div>

    {/* Cream Glow */}
    <div
        style={{
            position: "absolute",
            width: "900px",
            height: "450px",
            borderRadius: "50%",
            background:
                "radial-gradient(circle, rgba(248,243,239,.35), rgba(165,106,69,.12), transparent 75%)",
            filter: "blur(45px)",
        }}
    ></div>

    {/* Content */}
    <div
        style={{
            position: "relative",
            zIndex: 2,
            maxWidth: "900px",
            padding: "20px",
        }}
    >
        {/* Badge */}
        <span
            style={{
                display: "inline-block",
                padding: "10px 24px",
                borderRadius: "40px",
                background: "#8C3C11",
                color: "#F8F3EF",
                border: "1px solid #A56A45",
                fontSize: "12px",
                fontWeight: "600",
                letterSpacing: "2px",
                textTransform: "uppercase",
                marginBottom: "30px",
                fontFamily: "Poppins, sans-serif",
                boxShadow: "0 4px 15px rgba(140,60,17,0.35)",
            }}
        >
            DIGITAL SCRIPTORIUM
        </span>

        {/* Heading */}
        <h1
            style={{
                fontFamily: "'Playfair Display', serif",
                fontSize: "68px",
                fontWeight: "700",
                lineHeight: "1.15",
                color: "#F8F3EF",
                margin: "20px 0",
                textShadow: "2px 3px 10px rgba(0,0,0,0.35)",
            }}
        >
            Preserving the Past,
            <br />
            Flowing into the Future.
        </h1>

        {/* Subtitle */}
        <p
            style={{
                fontFamily: "Poppins, sans-serif",
                color: "#F8F3EF",
                fontSize: "20px",
                letterSpacing: "0.5px",
                lineHeight: "1.8",
                marginTop: "18px",
                maxWidth: "700px",
                marginLeft: "auto",
                marginRight: "auto",
                opacity: "0.95",
            }}
        >
            Bridges historical archives with modern interactive visual timelines.
        </p>
    </div>
</section>


        {/* Why Customers Trust Us Section */}

<section
  className="py-5"
  style={{
    background: "#F8F3EF",
  }}
>
  <div className="container">

    {/* Heading */}
    <div className="text-center mb-5">
      <h6
        style={{
          color: "#8C3C11",
          fontWeight: "600",
          letterSpacing: "2px",
          textTransform: "uppercase",
        }}
      >
        WHY CHOOSE ERAFLOW
      </h6>

      <h1
        style={{
          fontSize: "55px",
          fontWeight: "700",
          color: "#8C3C11",
          fontFamily: "'Playfair Display', serif",
        }}
      >
        Why Explore History With Us
      </h1>

      <p
        style={{
          color: "#7D7D7D",
          fontSize: "20px",
          maxWidth: "850px",
          margin: "auto",
          lineHeight: "1.8",
        }}
      >
        Discover history through interactive timelines, verified archives,
        immersive stories, and beautifully organized historical collections.
      </p>
    </div>

    {/* Cards */}
    <div className="row g-4">

      {/* Card 1 */}
      <div className="col-lg-3 col-md-6">
        <div
          className="text-center h-100"
          style={{
            background: "#FFFFFF",
            borderRadius: "22px",
            padding: "45px 25px",
            border: "1px solid #E8E2DC",
            boxShadow: "0 8px 20px rgba(140,60,17,0.12)",
            transition: "0.3s",
          }}
        >
          <i
            className="bi bi-clock-history"
            style={{
              fontSize: "70px",
              color: "#8C3C11",
            }}
          ></i>

          <h2
            style={{
              fontWeight: "700",
              marginTop: "25px",
              color: "#8C3C11",
              fontSize: "30px",
            }}
          >
            Interactive Timelines
          </h2>

          <p
            style={{
              color: "#7D7D7D",
              fontSize: "20px",
              marginTop: "15px",
            }}
          >
            Explore historical events through engaging visual timelines.
          </p>
        </div>
      </div>

      {/* Card 2 */}
      <div className="col-lg-3 col-md-6">
        <div
          className="text-center h-100"
          style={{
            background: "#FFFFFF",
            borderRadius: "22px",
            padding: "45px 25px",
            border: "1px solid #E8E2DC",
            boxShadow: "0 8px 20px rgba(140,60,17,0.12)",
          }}
        >
          <i
            className="bi bi-journal-bookmark"
            style={{
              fontSize: "70px",
              color: "#8C3C11",
            }}
          ></i>

          <h2
            style={{
              fontWeight: "700",
              marginTop: "25px",
              color: "#8C3C11",
              fontSize: "30px",
            }}
          >
            Historical Archives
          </h2>

          <p
            style={{
              color: "#7D7D7D",
              fontSize: "20px",
              marginTop: "15px",
            }}
          >
            Access authentic documents and carefully preserved records.
          </p>
        </div>
      </div>

      {/* Card 3 */}
      <div className="col-lg-3 col-md-6">
        <div
          className="text-center h-100"
          style={{
            background: "#FFFFFF",
            borderRadius: "22px",
            padding: "45px 25px",
            border: "1px solid #E8E2DC",
            boxShadow: "0 8px 20px rgba(140,60,17,0.12)",
          }}
        >
          <i
            className="bi bi-globe2"
            style={{
              fontSize: "70px",
              color: "#8C3C11",
            }}
          ></i>

          <h2
            style={{
              fontWeight: "700",
              marginTop: "25px",
              color: "#8C3C11",
              fontSize: "30px",
            }}
          >
            Global Civilizations
          </h2>

          <p
            style={{
              color: "#7D7D7D",
              fontSize: "20px",
              marginTop: "15px",
            }}
          >
            Journey through cultures, kingdoms, and civilizations worldwide.
          </p>
        </div>
      </div>

      {/* Card 4 */}
      <div className="col-lg-3 col-md-6">
        <div
          className="text-center h-100"
          style={{
            background: "#FFFFFF",
            borderRadius: "22px",
            padding: "45px 25px",
            border: "1px solid #E8E2DC",
            boxShadow: "0 8px 20px rgba(140,60,17,0.12)",
          }}
        >
          <i
            className="bi bi-book-half"
            style={{
              fontSize: "70px",
              color: "#8C3C11",
            }}
          ></i>

          <h2
            style={{
              fontWeight: "700",
              marginTop: "25px",
              color: "#8C3C11",
              fontSize: "30px",
            }}
          >
            Rich Knowledge
          </h2>

          <p
            style={{
              color: "#7D7D7D",
              fontSize: "20px",
              marginTop: "15px",
            }}
          >
            Learn fascinating stories that shaped the modern world.
          </p>
        </div>
      </div>

    </div>

  </div>
</section>



     {/* Contact Information Section */}

<section
  className="py-5"
  style={{
    background: "#F8F3EF",
  }}
>
  <div className="container">

    {/* Heading */}
    <div className="text-center mb-5">
      <h6
        style={{
          color: "#A56A45",
          fontWeight: "600",
          letterSpacing: "2px",
          textTransform: "uppercase",
        }}
      >
        GET IN TOUCH
      </h6>

      <h2
        style={{
          color: "#8C3C11",
          fontFamily: "'Playfair Display', serif",
          fontSize: "52px",
          fontWeight: "700",
          marginTop: "10px",
        }}
      >
        Contact Us
      </h2>

      <p
        style={{
          color: "#6B5A50",
          fontSize: "18px",
          maxWidth: "650px",
          margin: "15px auto 0",
          lineHeight: "1.8",
        }}
      >
        We'd love to hear from you. Reach out to EraFlow for archive
        information, collaborations or any historical queries.
      </p>
    </div>

    <div
      className="row justify-content-center g-4"
      style={{
        marginTop: "20px",
      }}
    >

      {/* Card 1 */}
      <div className="col-lg-3 col-md-6">
        <div
          className="text-center h-100"
          style={{
            position: "relative",
            background: "linear-gradient(to bottom,#FFFDF8,#F5E8D2)",
            border: "2px solid #D1AE73",
            borderRadius: "28px",
            padding: "50px 30px",
            boxShadow: "0 15px 35px rgba(140,60,17,.18)",
            overflow: "hidden",
          }}
        >

          {/* Top Roll */}
          <div
            style={{
              position: "absolute",
              top: "-8px",
              left: "50%",
              transform: "translateX(-50%)",
              width: "80%",
              height: "10px",
              background: "#A56A45",
              borderRadius: "20px",
            }}
          ></div>

          {/* Bottom Roll */}
          <div
            style={{
              position: "absolute",
              bottom: "-8px",
              left: "50%",
              transform: "translateX(-50%)",
              width: "80%",
              height: "10px",
              background: "#A56A45",
              borderRadius: "20px",
            }}
          ></div>

          <div
            style={{
              width: "90px",
              height: "90px",
              margin: "0 auto 20px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <i
              className="bi bi-journal-richtext"
              style={{
                fontSize: "50px",
                color: "#8C3C11",
              }}
            ></i>
          </div>

          <h4
            style={{
              color: "#8C3C11",
              fontFamily: "'Playfair Display', serif",
              fontWeight: "700",
              fontSize: "38px",
            }}
          >
            Our Archive
          </h4>

          <p
            style={{
              color: "#6B5A50",
              fontSize: "18px",
              lineHeight: "1.9",
              marginTop: "18px",
            }}
          >
            EraFlow Digital Museum
            <br />
            Heritage Research Centre
            <br />
            India
          </p>
        </div>
      </div>

      {/* Card 2 */}
      <div className="col-lg-3 col-md-6">
        <div
          className="text-center h-100"
          style={{
            position: "relative",
            background: "linear-gradient(to bottom,#FFFDF8,#F5E8D2)",
            border: "2px solid #D1AE73",
            borderRadius: "28px",
            padding: "50px 30px",
            boxShadow: "0 15px 35px rgba(140,60,17,.18)",
            overflow: "hidden",
          }}
        >

          {/* Top Roll */}
          <div
            style={{
              position: "absolute",
              top: "-8px",
              left: "50%",
              transform: "translateX(-50%)",
              width: "80%",
              height: "10px",
              background: "#A56A45",
              borderRadius: "20px",
            }}
          ></div>

          {/* Bottom Roll */}
          <div
            style={{
              position: "absolute",
              bottom: "-8px",
              left: "50%",
              transform: "translateX(-50%)",
              width: "80%",
              height: "10px",
              background: "#A56A45",
              borderRadius: "20px",
            }}
          ></div>

          <div
            style={{
              width: "90px",
              height: "90px",
              margin: "0 auto 20px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <i
              className="bi bi-telephone-fill"
              style={{
                fontSize: "50px",
                color: "#8C3C11",
              }}
            ></i>
          </div>

          <h4
            style={{
              color: "#8C3C11",
              fontFamily: "'Playfair Display', serif",
              fontWeight: "700",
              fontSize: "38px",
            }}
          >
            Contact Us
          </h4>

          <p
            style={{
              color: "#6B5A50",
              fontSize: "18px",
              lineHeight: "1.9",
              marginTop: "18px",
            }}
          >
            +91 98765 43210
            <br />
            Mon – Sat
            <br />
            9:00 AM – 6:00 PM
          </p>
        </div>
      </div>


            {/* Card 3 */}
      <div className="col-lg-3 col-md-6">
        <div
          className="text-center h-100"
          style={{
            position: "relative",
            background: "linear-gradient(to bottom,#FFFDF8,#F5E8D2)",
            border: "2px solid #D1AE73",
            borderRadius: "28px",
            padding: "50px 30px",
            boxShadow: "0 15px 35px rgba(140,60,17,.18)",
            overflow: "hidden",
          }}
        >

          {/* Top Roll */}
          <div
            style={{
              position: "absolute",
              top: "-8px",
              left: "50%",
              transform: "translateX(-50%)",
              width: "80%",
              height: "10px",
              background: "#A56A45",
              borderRadius: "20px",
            }}
          ></div>

          {/* Bottom Roll */}
          <div
            style={{
              position: "absolute",
              bottom: "-8px",
              left: "50%",
              transform: "translateX(-50%)",
              width: "80%",
              height: "10px",
              background: "#A56A45",
              borderRadius: "20px",
            }}
          ></div>

          <div
            style={{
              width: "90px",
              height: "90px",
              margin: "0 auto 20px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <i
              className="bi bi-clock-history"
              style={{
                fontSize: "50px",
                color: "#8C3C11",
              }}
            ></i>
          </div>

          <h4
            style={{
              color: "#8C3C11",
              fontFamily: "'Playfair Display', serif",
              fontWeight: "700",
              fontSize: "38px",
            }}
          >
            Open Hours
          </h4>

          <p
            style={{
              color: "#6B5A50",
              fontSize: "18px",
              lineHeight: "1.9",
              marginTop: "18px",
            }}
          >
            Monday – Saturday
            <br />
            9:00 AM – 6:00 PM
          </p>
        </div>
      </div>

      {/* Card 4 */}
      <div className="col-lg-3 col-md-6">
        <div
          className="text-center h-100"
          style={{
            position: "relative",
            background: "linear-gradient(to bottom,#FFFDF8,#F5E8D2)",
            border: "2px solid #D1AE73",
            borderRadius: "28px",
            padding: "50px 30px",
            boxShadow: "0 15px 35px rgba(140,60,17,.18)",
            overflow: "hidden",
          }}
        >

          {/* Top Roll */}
          <div
            style={{
              position: "absolute",
              top: "-8px",
              left: "50%",
              transform: "translateX(-50%)",
              width: "80%",
              height: "10px",
              background: "#A56A45",
              borderRadius: "20px",
            }}
          ></div>

          {/* Bottom Roll */}
          <div
            style={{
              position: "absolute",
              bottom: "-8px",
              left: "50%",
              transform: "translateX(-50%)",
              width: "80%",
              height: "10px",
              background: "#A56A45",
              borderRadius: "20px",
            }}
          ></div>

          <div
            style={{
              width: "90px",
              height: "90px",
              margin: "0 auto 20px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <i
              className="bi bi-envelope-fill"
              style={{
                fontSize: "50px",
                color: "#8C3C11",
              }}
            ></i>
          </div>

          <h4
            style={{
              color: "#8C3C11",
              fontFamily: "'Playfair Display', serif",
              fontWeight: "700",
              fontSize: "38px",
            }}
          >
            Email
          </h4>

          <p
            style={{
              color: "#6B5A50",
              fontSize: "18px",
              lineHeight: "1.9",
              marginTop: "18px",
            }}
          >
            support@eraflow.com
            <br />
            info@eraflow.com
          </p>
        </div>
      </div>

    </div>
  </div>
</section>


{/* ===================== TESTIMONIALS ===================== */}

<section
  className="py-5"
  style={{
    background: "#F8F3EF",
  }}
>
  <div className="container">

    {/* Heading */}
    <div className="text-center mb-5">
      <h6
        style={{
          color: "#A56A45",
          letterSpacing: "2px",
          fontWeight: "600",
          textTransform: "uppercase",
        }}
      >
        TESTIMONIALS
      </h6>

      <h2
        style={{
          color: "#8C3C11",
          fontFamily: "'Playfair Display', serif",
          fontSize: "52px",
          fontWeight: "700",
          marginTop: "10px",
        }}
      >
        What Our Visitors Say
      </h2>

      <p
        style={{
          color: "#6B5A50",
          fontSize: "18px",
          maxWidth: "700px",
          margin: "15px auto 0",
          lineHeight: "1.8",
        }}
      >
        Hear from history enthusiasts, researchers and students who explored
        India's heritage through EraFlow.
      </p>
    </div>

    <div className="row text-center g-5">

      {/* Testimonial 1 */}
      <div className="col-lg-4">

        <img
          src="https://randomuser.me/api/portraits/women/65.jpg"
          alt=""
          style={{
            width: "120px",
            height: "120px",
            borderRadius: "50%",
            objectFit: "cover",
            border: "4px solid #C89B3C",
            boxShadow: "0 10px 25px rgba(140,60,17,.18)",
          }}
        />

        <p
          style={{
            color: "#6B5A50",
            fontSize: "22px",
            fontStyle: "italic",
            marginTop: "30px",
            lineHeight: "1.8",
          }}
        >
          "EraFlow beautifully presents India's history. The timelines and
          historical archives made learning engaging and memorable."
        </p>

        <h4
          style={{
            color: "#8C3C11",
            fontFamily: "'Playfair Display', serif",
            fontWeight: "700",
            marginTop: "20px",
          }}
        >
          Priya Sharma
        </h4>

        <p
          style={{
            color: "#7D7D7D",
            fontSize: "18px",
          }}
        >
          History Student
        </p>

        <div
          style={{
            color: "#C89B3C",
            fontSize: "26px",
          }}
        >
          ★★★★★
        </div>

      </div>

      {/* Testimonial 2 */}
      <div className="col-lg-4">

        <img
          src="https://randomuser.me/api/portraits/men/44.jpg"
          alt=""
          style={{
            width: "120px",
            height: "120px",
            borderRadius: "50%",
            objectFit: "cover",
            border: "4px solid #C89B3C",
            boxShadow: "0 10px 25px rgba(140,60,17,.18)",
          }}
        />

        <p
          style={{
            color: "#6B5A50",
            fontSize: "22px",
            fontStyle: "italic",
            marginTop: "30px",
            lineHeight: "1.8",
          }}
        >
          "The interactive maps and historical leaders section are incredibly
          informative. A wonderful platform for heritage lovers."
        </p>

        <h4
          style={{
            color: "#8C3C11",
            fontFamily: "'Playfair Display', serif",
            fontWeight: "700",
            marginTop: "20px",
          }}
        >
          Rahul Deshmukh
        </h4>

        <p
          style={{
            color: "#7D7D7D",
            fontSize: "18px",
          }}
        >
          Heritage Researcher
        </p>

        <div
          style={{
            color: "#C89B3C",
            fontSize: "26px",
          }}
        >
          ★★★★★
        </div>

      </div>

      {/* Testimonial 3 */}
      <div className="col-lg-4">

        <img
          src="https://randomuser.me/api/portraits/women/32.jpg"
          alt=""
          style={{
            width: "120px",
            height: "120px",
            borderRadius: "50%",
            objectFit: "cover",
            border: "4px solid #C89B3C",
            boxShadow: "0 10px 25px rgba(140,60,17,.18)",
          }}
        />

        <p
          style={{
            color: "#6B5A50",
            fontSize: "22px",
            fontStyle: "italic",
            marginTop: "30px",
            lineHeight: "1.8",
          }}
        >
          "A beautifully designed digital archive. It makes exploring India's
          cultural legacy enjoyable and easy for everyone."
        </p>

        <h4
          style={{
            color: "#8C3C11",
            fontFamily: "'Playfair Display', serif",
            fontWeight: "700",
            marginTop: "20px",
          }}
        >
          Ananya Patel
        </h4>

        <p
          style={{
            color: "#7D7D7D",
            fontSize: "18px",
          }}
        >
          Museum Visitor
        </p>

        <div
          style={{
            color: "#C89B3C",
            fontSize: "26px",
          }}
        >
          ★★★★★
        </div>

      </div>

    </div>

  </div>
</section>


   </>
);
}

export default Home;